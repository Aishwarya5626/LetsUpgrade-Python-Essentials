def Fibonacci_series(calculate_fibo_series):
    def fibo_function():
        print("Enter the range of fibonacci series")
        num=int(input("range of fibonacci series:"))
        calculate_fibo_series(num)
    return fibo_function
@Fibonacci_series
def fibonacci(x):
    A=0
    B=1
    if A==1:
        print(A)
    else:
        print(A)
        print(B)
    for i in range(2,x):
        C=A+B
        A=B
        B=C
        print(C)
    return fibonacci
fibonacci()


