lower=int(input("enter staring value:"))
upper=int(input("enter upper value"))
for num in range(lower,upper+1):
    if num>1:
        for a in range(2,num):
            if (num%a) ==0:
                break
        else:
         print(num)
