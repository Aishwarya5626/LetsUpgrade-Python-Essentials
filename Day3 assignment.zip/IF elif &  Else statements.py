print("Altitude rules for landing plane")
Altitude=int(input("Enter Altitude:"))
if Altitude<=1000:
    print("Safe to land")
elif 1000<Altitude<5000:
    print("Bring down to 1000")
else:
    print("Turn around and try later")