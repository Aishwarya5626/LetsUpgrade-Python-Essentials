def PrimeNumber(num):
    if num > 1:
        for a in range(2, num):
            if (num % a) == 0:
                return False
        return True
lst = list(range(1, 2501))
lst_prime_num = filter(PrimeNumber, lst)
print(list(lst_prime_num))
