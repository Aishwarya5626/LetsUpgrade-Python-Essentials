lst=["hey this is sai","i am in mumbai,..."]
lst_new=map(lambda x:x.title(),lst)
print(list(lst_new))
