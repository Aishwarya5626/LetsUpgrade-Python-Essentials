mystr="Impossible itself says I'm possible"
print(mystr.isalnum())
print(mystr.upper())
print(mystr.lower())
print(mystr.capitalize())
print(mystr.replace("I'm","I am"))
print(mystr.find("possible"))
print(mystr.endswith("boy"))
print(mystr.casefold())
