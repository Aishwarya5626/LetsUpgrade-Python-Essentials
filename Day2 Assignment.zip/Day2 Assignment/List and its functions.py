# list and its functions
Numbers=[1,2,3,2,5,1,1,8]
Numbers.sort()
print(Numbers)
Numbers.reverse()
print(Numbers)
Numbers.append(41)
print(Numbers)
print(max(Numbers))
print(min(Numbers))
Numbers.pop()
print(Numbers)

