a=(1,2,7,21,81,36,2,2,2)
print(len(a))
print(max(a))
print(min(a))
print(a.count(2))
print(a.index(36))


