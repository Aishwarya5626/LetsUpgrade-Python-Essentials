d1={"Trust":"To believe that someone is good and honest and will not hurt you,or that something is safe and reliable.You can also check this meaning at https://dictionary.cambridge.org/dictionary/english/trust",
    "Idim":"An expression whose meaning is different from the meanings of the individual words in it",
"Compile":"To collect information and arrange it in a list, book,etc.",
 "pooh":"Check the given URL-https://www.lexico.com/defination/pooh-pooh"}
print(d1.get("Trust"))
d1.update({"Pretty":"Beautiful"})
print(d1)
print(d1.keys())
print(d1.items())
d2=d1.copy()
print(d2)